$( document ).ready(function() {
  window.mySwipe = new Swipe(document.getElementById('slider'), {
    speed: 300,
    auto: 3000, // define duration slide
    continuous: true,
    disableScroll: true,
    stopPropagation: false,
    callback: function(index, elem) {
    },
    transitionEnd: function(index, elem) {
    }
  });
});
