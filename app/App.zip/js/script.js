$( document ).ready(function() {
  window.mySwipe = new Swipe(document.getElementById('slider'), {
    speed: 300,
    // auto: 3000,
    continuous: true,
    disableScroll: true,
    stopPropagation: false,
    callback: function(index, elem) {
    },
    transitionEnd: function(index, elem) {
    }
  });
});
