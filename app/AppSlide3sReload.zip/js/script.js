var timer;

$( document ).ready(function() {
  window.mySwipe = new Swipe(document.getElementById('slider'), {
    speed: 300,
    auto: 3000, // define duration slide
    continuous: true,
    disableScroll: true,
    stopPropagation: false,
    callback: function(index, elem) {
      window.clearTimeout(timer);
      timer = window.setTimeout(function(){ document.location.href = 'index.html'; },30000); 
    },
    transitionEnd: function(index, elem) {
    }
  });
});
